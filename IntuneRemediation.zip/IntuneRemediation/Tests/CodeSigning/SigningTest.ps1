# Simple test script for code signing
Write-Host "This is a test script for code signing."
Write-Host "If this script can be signed, we can identify what's causing the issue."

# Test basic PowerShell functionality
Get-Date
Write-Host "PowerShell Version: $($PSVersionTable.PSVersion)"
Write-Host "PowerShell Edition: $($PSVersionTable.PSEdition)" 